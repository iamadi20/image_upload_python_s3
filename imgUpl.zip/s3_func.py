from urllib import response
import boto3



def upload_file(file_name, bucket):
    object_name = 'user_image/'+file_name
    print('object',object_name)
    s3_client = boto3.client('s3')
    response = s3_client.upload_file(file_name, bucket, object_name)
    return response


def uploadSku(file_name,bucket):
    object_name='sku_image/'+file_name
    s3_client=boto3.client('s3')
    response=s3_client.upload_file(file_name,bucket,object_name)
    return response
