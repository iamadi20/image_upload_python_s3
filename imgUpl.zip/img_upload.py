import os
from flask import Flask, render_template, request, redirect, send_file,jsonify
from s3_functions import upload_file,uploadSku
from werkzeug.utils import secure_filename
from datetime import datetime,date

app = Flask(__name__)
UPLOAD_FOLDER = "/home/ubuntu/vitaranWeb/helper/uploads"
BUCKET = "vitaran"
@app.route("/VitaranSDK/uploadPartnerImage", methods=['POST'])
def upload():
    if request.method == "POST":
        if request.files['file']=='' or request.files['file'] is None:
            return jsonify({"Result":"Error","Code":416,"message":"Please provide a File to upload."})
        else:
            url='https://vitaran.s3.ap-south-1.amazonaws.com/user_image/'
            dt = datetime.now().strftime('%y%m%d%H%M%f')
            f = request.files['file']
            f.filename="%s%s"%(dt,'.png')
            f.save(f.filename)
            print(f.filename)
            upload_file(f.filename, BUCKET)
            resp=jsonify({"response_code":200,"image_name":f.filename,"image_url":url+f.filename})
        resp.headers.add('Access-Control-Allow-Origin', '*')
        return resp

@app.route("/VitaranSDK/uploadSkuImage", methods=['POST'])
def upload_sku():
    if request.method == "POST":
        if request.files['file']=='' or request.files['file'] is None:
            return jsonify({"Result":"Error","Code":416,"message":"Please provide a File to upload."})
        else:
            url='https://vitaran.s3.ap-south-1.amazonaws.com/sku_image/'
            dt = datetime.now().strftime('%y%m%d%H%M%f')
            f = request.files['file']
            f.filename="%s%s"%(dt,'.png')
            f.save(f.filename)
            print(f.filename)
            uploadSku(f.filename, BUCKET)
            resp=jsonify({"response_code":200,"image_name":f.filename,"image_url":url+f.filename})
        resp.headers.add('Access-Control-Allow-Origin', '*')
        return resp




if __name__ == '__main__':
    app.run(host='0.0.0.0', port='3200')
